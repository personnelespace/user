/* 
*   SiteFactory Common JS
*/
if (typeof (sfCookieErrorPage) != "undefined") {
	if (!navigator.cookieEnabled && (window.location.href.indexOf(sfCookieErrorPage) < 0)) {
		window.location = window.location.protocol + "//" + window.location.host + "/sites/" + sfSiteId + "/" + sfCookieErrorPage + "?axes1=" + sfAxes1 + "&axes2=" + sfAxes2 + "&axes3=" + sfAxes3 + "&axes4=" + sfAxes4;
	}
}
