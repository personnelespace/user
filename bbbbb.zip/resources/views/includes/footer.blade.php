
<div class="ls-row" id="footer">
   <div class="ls-fxr" id="ls-gen33001738-ls-fxr">
   <div class="ls-area footerContent" id="footerContent">
       <div class="ls-area-body" id="ls-gen33001739-ls-area-body">
           <div class="ls-cmp-wrap ls-1st" id="w1413474750477">
               <div class="iw_component" id="1413474750477">
                   
                   <!--content start-->
                   <div id="">
<div class="wcm-html style-default part ">
   <footer id="default-footer-refresh">   
        <div class="footer-section_reseaux-sociaux">     
               <div class="footer-section_reseaux-sociaux-container">     
                          <span>Suivez-nous sur :</span>           
                           <a href="#"> 
                                <!-- <img src="/rsc/contrib/image/particuliers/homepage/fb.svg" alt="facebook"> --> 
                                 <svg xmlns="http://www.w3.org/2000/svg" width="8" height="19" viewBox="0 0 8 19">      <g fill="none" fill-rule="evenodd">          <path fill="#FFF" d="M8 8.83H5.356V19H1.678V8.72H0V5.787h1.678c0-1.745-1-6.422 6.286-5.715v3.45c-1.179 0-2.642-.296-2.642 2.265H8v3.042z"></path>      </g>  </svg>            </a>            <a href="https://twitter.com/mabanque_bnpp">  <svg xmlns="http://www.w3.org/2000/svg" width="23" height="19" viewBox="0 0 23 19">      <g fill="none" fill-rule="evenodd">          <path fill="#FFF" d="M7.396 19C3.95 19 .81 17.546 0 16.923c0 0 3.85.727 6.787-2.073-1.518-.518-3.342-.933-4.152-3.318.91.207.91.207 1.823-.103C2.937 10.704 1.621 9.562.81 6.763c.811.414 1.622.621 2.23.621C1.62 5.829.203 3.654 1.518.956c.914.831 4.967 5.288 9.731 4.873 0-2.28.708-4.25 2.329-5.184 1.621-.934 4.359-1.037 5.674.935 1.047.552 2.838.415 3.748 0-.405.83-1.824 2.696-2.532 3.213C20.568 5.622 19.86 19 7.396 19z"></path>      </g>  </svg>            </a>            <a href="https://www.youtube.com/channel/UCJeiOCUqrEbMqvqjuYVSihQ/">  <svg xmlns="http://www.w3.org/2000/svg" width="27" height="19" viewBox="0 0 27 19">      <g fill="none" fill-rule="evenodd">          <path fill="#FFF" d="M11.713 13.004l-.002-7.59 7.296 3.808-7.294 3.782zM26.73 4.099s-.264-1.861-1.073-2.682C24.63.342 23.479.336 22.952.273 19.173 0 13.506 0 13.506 0h-.012S7.827 0 4.048.273C3.521.336 2.37.342 1.343 1.417.533 2.237.27 4.099.27 4.099S0 6.285 0 8.47v2.049c0 2.187.27 4.372.27 4.372s.264 1.862 1.073 2.681C2.37 18.65 3.72 18.616 4.32 18.73c2.16.207 9.18.271 9.18.271s5.673-.008 9.452-.281c.527-.063 1.678-.07 2.705-1.146.81-.819 1.073-2.68 1.073-2.68s.27-2.186.27-4.373V8.471c0-2.186-.27-4.372-.27-4.372z"></path>      </g>  </svg>          </a>            <a href="https://www.instagram.com/mabanquebnpparibas/">  <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="19" height="19" viewBox="0 0 19 19">      <defs>          <path id="a" d="M0 .006h18.994v18.992H0z"></path>      </defs>      <g fill="none" fill-rule="evenodd">          <g><mask id="b" fill="#fff">    <use xlink:href="#a"></use></mask><path fill="#FFF" d="M9.497.006c-2.58 0-2.903.01-3.916.057-1.01.046-1.7.207-2.305.442A4.655 4.655 0 0 0 1.594 1.6 4.655 4.655 0 0 0 .499 3.282C.264 3.886.103 4.577.057 5.587.011 6.6 0 6.924 0 9.503c0 2.58.01 2.903.057 3.916.046 1.01.207 1.7.442 2.305a4.655 4.655 0 0 0 1.095 1.682 4.656 4.656 0 0 0 1.682 1.095c.604.235 1.295.396 2.305.442 1.013.046 1.337.057 3.916.057 2.58 0 2.903-.01 3.916-.057 1.01-.046 1.7-.207 2.305-.442a4.656 4.656 0 0 0 1.682-1.095 4.656 4.656 0 0 0 1.095-1.682c.235-.604.396-1.295.442-2.305.046-1.013.057-1.337.057-3.916 0-2.58-.01-2.903-.057-3.916-.046-1.01-.207-1.7-.442-2.305A4.656 4.656 0 0 0 17.4 1.6 4.655 4.655 0 0 0 15.718.505C15.114.27 14.423.109 13.413.063 12.4.017 12.076.006 9.497.006zm0 1.711c2.536 0 2.836.01 3.838.056.926.042 1.428.196 1.763.327.443.172.76.378 1.092.71.332.332.538.649.71 1.092.13.335.285.837.327 1.763.046 1.002.056 1.302.056 3.838s-.01 2.836-.056 3.838c-.042.926-.196 1.428-.327 1.763-.172.443-.378.76-.71 1.092a2.942 2.942 0 0 1-1.092.71c-.335.13-.837.285-1.763.327-1.002.046-1.302.056-3.838.056s-2.836-.01-3.838-.056c-.926-.042-1.428-.196-1.763-.327a2.942 2.942 0 0 1-1.092-.71 2.943 2.943 0 0 1-.71-1.092c-.13-.335-.285-.837-.327-1.763-.046-1.002-.056-1.302-.056-3.838s.01-2.836.056-3.838c.042-.926.196-1.428.327-1.763.172-.443.378-.76.71-1.092a2.942 2.942 0 0 1 1.092-.71c.335-.13.837-.285 1.763-.327 1.002-.046 1.302-.056 3.838-.056z" mask="url(#b)"></path>          </g>          <path fill="#FFF" d="M9.497 12.669a3.166 3.166 0 1 1 0-6.332 3.166 3.166 0 0 1 0 6.332zm0-8.043a4.877 4.877 0 1 0 0 9.754 4.877 4.877 0 0 0 0-9.754zM15.706 4.433a1.14 1.14 0 1 1-2.28 0 1.14 1.14 0 0 1 2.28 0"></path>      </g>  </svg>            </a>            <a href="https://www.linkedin.com/company/bnp-paribas/">  <svg xmlns="http://www.w3.org/2000/svg" width="20" height="19" viewBox="0 0 20 19">      <g fill="none" fill-rule="evenodd">          <path fill="#FFFFFE" d="M16.518 16.19h-2.873v-4.41c0-1.05-.02-2.403-1.494-2.403-1.496 0-1.726 1.145-1.726 2.328v4.486H7.553V7.123h2.757v1.239h.039c.384-.713 1.322-1.464 2.72-1.464 2.912 0 3.45 1.878 3.45 4.319v4.974zM4.312 5.885c-.921 0-1.667-.733-1.667-1.635 0-.901.746-1.633 1.667-1.633.92 0 1.667.732 1.667 1.633 0 .902-.747 1.635-1.667 1.635zM2.874 16.19h2.875V7.123H2.874v9.068zM17.95 0H1.43C.642 0 0 .613 0 1.37v16.26C0 18.385.641 19 1.43 19h16.52c.791 0 1.435-.614 1.435-1.37V1.37c0-.757-.644-1.37-1.435-1.37z"></path>      </g>  </svg>            </a>     
                                  </div> 
                                  </div>  
                                  
                                  
                                  <div class="footer-section">  
                                             <a href="#" class="footer-section_container1 col-3 mob-50">           
                                                <span class="footer-section_titre1">Contact</span>         
                                                   <p class="footer-section_content1">  Nos conseillers vous répondent par téléphone, chat, mail ou bien encore grâce à nos SAV Facebook et Twitter.            </p>      
                                                 </a>     
                                                      <a href="#" class="footer-section_container1 col-3 mob-50">         
                                                          <span class="footer-section_titre1">Trouver une agence</span>      
                                                             <p class="footer-section_content1">  Retrouvez facilement l’agence la plus proche avec ses horaires d’ouverture et les services disponibles.            </p>       
                                                    </a>    
                                                                  <a href="#" class="footer-section_container1 col-3 mob-50">   
                                                                              <span class="footer-section_titre1">les applications mobiles</span>     
                                                                                     <p class="footer-section_content1">  Découvrez nos applications mobiles pour gérer vos comptes, payer avec votre mobile et vous simplifier la vie.            </p>      
                                          </a>   
                                 </div>   
                                                          
                                                          <div class="footer-section">      
                                                                <div class="footer-section_container2 col-4 mob-100">     
                                                                           <span class="footer-section_titre2">Informations légales</span>    
                                                                                   <ul class="footer-section_liens"> 
                                                                                        <li><a href="#" class="footer-section_liens-el">Données personnelles</a></li> 
                                                                                         <li>
                                                                                             <a href="#" class="footer-section_liens-el">Mentions légales</a></li>  
                                                                                         <li><a href="#" class="footer-section_liens-el">Cookies</a></li> 
                                                                                          <li><a href="#">Réglementation</a></li> 
                                                                                          <li><a href="#" class="footer-section_liens-el">Fonds de Garantie des Dépôts et résolution</a></li>        
                                                                                   </ul>      
                                                                </div>   
                                                                                              <div class="footer-section_container2 col-4 mob-100">          
                                                                                               <span class="footer-section_titre2">Nous connaître</span>           
                                    <ul class="footer-section_liens">          
         <li><a href="#" class="footer-section_liens-el">La banque d’un monde qui change</a></li>        
           <li><a href="#" class="footer-section_liens-el">Nos engagements responsables</a></li>     
      </ul>     
  </div>   
        <div class="footer-section_container2 col-4 mob-100">        
       <span class="footer-section_titre2">Informations</span>    
           <ul class="footer-section_liens">		
         <li><a href="#" class="footer-section_liens-el lien-footer-accessible">Site Accessible</a></li>        
           <li><a href="#" class="footer-section_liens-el">Site Sécurisé</a></li>       
            <li><a href="#" class="footer-section_liens-el">Conditions d’éligibilité</a></li>      
<li><a href="#" class="footer-section_liens-el">Tarifs et conditions</a></li>          
         <li><a href="#" class="footer-section_liens-el">Glossaire</a></li>        
           <li><a href="#" class="footer-section_liens-el">Guides et brochures</a></li>   
        </ul>     
  </div>        
   <div class="footer-section_container2 col-4 mob-100">  
<span class="footer-section_titre2">Nos autres sites</span>       
        <ul class="footer-section_liens">
     <li><a href="#" class="footer-section_liens-el" target="_blank">Les Professionnels</a></li> 
    <li><a href="#" class="footer-section_liens-el" target="_blank">Les Entreprises</a></li> 
     <li><a href="#" class="footer-section_liens-el" target="_blank">Les Associations</a></li> 
      <li><a href="#" class="footer-section_liens-el" target="_blank">La Banque Privée</a></li> 
       <li><a href="#" class="footer-section_liens-el" target="_blank">La Banque en ligne</a></li> 
        <li><a href="#" class="footer-section_liens-el" target="_blank">Le Groupe BNP Paribas</a></li>    
              </ul>     
               </div>  
               </div>   
                  <div class="footer-section"> 
                        <div class="footer-section_mentions-legales">     
                                  <p>  Pour la bonne exécution de vos contrats, et en cas de réclamations/contestations, votre Conseiller  est joignable sur sa ligne directe (appel non surtaxé). Si vous ne disposez plus de son numéro  de téléphone direct, envoyez-lui un message par votre messagerie sécurisée, il vous le donnera  à nouveau en retour.             </p>        
                 </div>  
                 </div>
               </footer>
                </div>
</div>
<!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1413474750478">
   <div class="iw_component" id="1413474750478"><!--content start-->
   <div id="wcm-l-">
<div class="wcm-richxml style-default "></div>
</div>
<!--content stop-->
</div>
</div>
<div class="ls-cmp-wrap" id="w1418660905840">
   <div class="iw_component" id="1418660905840"><!--content start-->
   <div id="wcm-l-">
<div class="wcm-richxml style-default "></div>
</div><!--content stop-->
</div></div><div class="ls-cmp-wrap" id="w1413474750479">
   <div class="iw_component" id="1413474750479">
   <div class="wcm-javascript style-default ">
<script type="text/javascript"></script>
</div>
</div>
</div>
</div>
</div>
<div class="ls-row-clr">
   </div>
</div>
</div>
</div>
<!--sf:end[div:sf-master]-->
</div>

<script src="./assets/js/webtrends.min.js"></script>
<div class="scroll-to-top-btn" style="display: block;"><i class="icon icon-back"></i></div>
<style>
   #wrapper-hub-offre-col100 input[name=cc-filtre].active+label {background-color: #067a6f;color: #fff;}
</style>

<div class="state-indicator"></div>
<style>
.inbenta-mobile-search{float:right!important;width:60px;font-size:25px;text-align:center;cursor:pointer}.inbenta-header-input{float:left;font-size:15px!important;margin-bottom:0!important}#recherche-site #autocomplete{position:inherit!important}#recherche-site .join-input3{width:80%;border-radius:0;margin-bottom:12px}#recherche-site .join-unit{text-align:center;width:20%;border-radius:0}#recherche-site .join-input3 ::-ms-input-placeholder,#recherche-site .join-input3 ::-webkit-input-placeholder{color:#b1b1b1}#recherche-site .join-input3 ::-moz-placeholder,#recherche-site ::-moz-placeholder{color:#b1b1b1;opacity:1}#inbenta-header-results,#recherche-site{width:calc(100% - 600px);margin-left:248px;top:0}.client #inbenta-header-results,.client #recherche-site{width:calc(100% - 630px)}#recherche-site{background-color:#fff;padding:10px 2% 0;box-shadow:0 0 5px 1px rgba(0,0,0,.2)}#inbenta-header-results{margin-top:60px}#recherche-site .inbenta-header-button{text-align:center;width:100%;border-radius:0;margin-bottom:12px;padding:0;font-size:15px;font-family:bnp_regular,Arial,sans-serif;background-color:#fafafa}.inbenta-container{width:calc(100% - 698px);margin-left:247px;height:500px}#inbenta-header-results #autocomplete.inbenta-interface{position:relative;left:inherit}#inbenta-header-results .inbenta-interface:not(#autocomplete){height:500px;background-color:#fff}@media screen and (min-width:1300px){#recherche-site .inbenta-header-button.inb-active{background-color:#1da35f;background-image:-webkit-linear-gradient(#1da35f,#1b9a5a);background-image:linear-gradient(#1da35f,#1b9a5a);border-bottom:solid 2px #188950;border-color:#188950;color:#FFF}#inbenta-header-results #autocomplete.inbenta-interface{width:74%;margin-left:3.8%}}@media screen and (min-width:1001px) and (max-width:1300px){#recherche-site .inbenta-header-button{color:transparent;background:url(/rsc/contrib/image/generique/sprite-header.png) 20px 12px no-repeat;cursor:pointer;width:60px;display:block}#recherche-site .join-input3{width:calc(100% - 60px)}#recherche-site .join-unit{width:60px}#recherche-site .inbenta-header-button.inb-active{background:url(/rsc/contrib/image/generique/sprite-header.png) 20px -85px no-repeat #1da35f;border-bottom:solid 2px #188950;border-color:#188950}#inbenta-header-results #autocomplete.inbenta-interface{width:78%;margin-left:4.8%}}@media screen and (min-width:641px) and (max-width:1000px){#recherche-site{width:100%;top:70px;margin:auto}#recherche-site.recherche-site-menu{width:calc(100% - 140px);margin-left:140px}#inbenta-header-results{margin-top:140px;width:100%;padding:0 2%;margin-left:0}#inbenta-header-results.recherche-site-menu{width:calc(100% - 140px);margin-left:140px}#inbenta-header-results #autocomplete.inbenta-interface{margin-top:3px;z-index:1000;position:relative;left:inherit;width:calc(100% - 60px);top:-10px}#inbenta-header-results .inbenta-interface:not(#autocomplete){height:350px}#recherche-site .join-input3{width:calc(100% - 60px)}#recherche-site .inbenta-header-button{color:transparent;background:url(/rsc/contrib/image/generique/sprite-header.png) 20px 12px no-repeat;cursor:pointer;width:60px;display:block}#recherche-site .join-unit{width:60px}#recherche-site .inbenta-header-button.inb-active{background:url(/rsc/contrib/image/generique/sprite-header.png) 20px -85px no-repeat #1da35f;border-bottom:solid 2px #188950;border-color:#188950}}@media screen and (max-width:640px){#inbenta-header-results,#recherche-site{width:100%;margin-left:0;top:70px}#recherche-site{padding:10px 1rem 0;box-shadow:none}#inbenta-header-results #autocomplete.inbenta-interface{position:absolute;width:calc(100% - 2rem);top:125px;margin:0 1rem}#inbenta-header-results .inbenta-interface:not(#autocomplete){position:fixed;height:calc(100% - 140px);top:140px;z-index:202}body.inbenta-fixed{position:fixed}#recherche-site .join-input3{width:calc(100% - 60px)}#recherche-site .inbenta-header-button{color:transparent;background:url(/rsc/contrib/image/generique/sprite-header.png) 20px 12px no-repeat;cursor:pointer;width:60px;display:block}#recherche-site .inbenta-header-button.inb-active{background:url(/rsc/contrib/image/generique/sprite-header.png) 20px -85px no-repeat #1da35f;border-bottom:solid 2px #188950;border-color:#188950}#recherche-site .join-unit{width:60px}}</style><div class="full-cache cache-recherche-qualifiee hidden">
   </div>
<div class="bg-nav" style="display: none;">
</div>
<script async="" src="./assets/js/CelebrusDynamicInsert.js"></script>
<div id="nextoutils_pointDeContact" class="hidden nextoutilsLoaded">
   </div>
<div id="nextoutils_gestionCookies" class="hidden nextoutilsLoaded">
   </div>
<ul class="ui-autocomplete ui-front ui-menu ui-widget ui-widget-content ui-corner-all" id="ui-id-1" tabindex="0" style="display: none;"
></ul>

