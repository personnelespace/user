	<script src="{{asset('js/vendor/jquery-library.js')}}"></script>
	<script src="{{asset('js/vendor/bootstrap.min.js')}}"></script>
	<script src="http://maps.google.com/maps/api/js?key=AIzaSyCR-KEWAVCn52mSdeVeTqZjtqbmVJyfSus&language=en"></script>
	<script src="{{asset('js/owl.carousel.min.js')}}"></script>
	<script src="{{asset('js/jquery.svgInject.js')}}"></script>
	<script src="{{asset('js/isotope.pkgd.j')}}"></script>
	<script src="{{asset('js/chartsloader.js')}}"></script>
	<script src="{{asset('js/parallax.js')}}"></script>
	<script src="{{asset('js/countTo.js')}}"></script>
	<script src="{{asset('js/appear.js')}}"></script>
	<script src="{{asset('js/gmap3.js')}}"></script>
	<script src="{{asset('js/main.js')}}"></script>
	<!-- <script>
	$('#login').click(function() {
    $('#myModal').modal();
});
	</script> -->
<script>
$(function() {
	$('#login').click(function() {
    $('#myModal').modal();
});
      
});   // Calling Login Form
      
</script>
<script>
	
</script>

