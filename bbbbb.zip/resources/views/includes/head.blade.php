<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>BNP Paribas | Ma banque en ligne</title>
<meta content="IE=edge,chrome=1" http-equiv="X-UA-compatible">
<link href="//db.onlinewebfonts.com/c/b83e22c3c6b9e118d3aa9299d27f1810?family=ShiliaW23-130UltLight" rel="stylesheet" type="text/css"/>

<link rel="stylesheet" href="{{ asset('css/font-awesome.min.css')}}">
<link rel="stylesheet" href="{{ asset('css/icomoon.css')}}">
<link type="text/css" href="{{ asset('css/home-new.css')}}" rel="stylesheet">
{{-- <meta name="description" content="BNP Paribas : banque et assurance. J&#39;accède à mes comptes et je consulte les produits et les services en ligne de ma banque."><!--ls:end[meta-description]--><!--ls:begin[meta-vpath]--><meta name="vpath" content=""><!--ls:end[meta-vpath]--><!--ls:begin[meta-page-locale-name]--><meta name="page-locale-name" content=""><!--ls:end[meta-page-locale-name]--><!--ls:begin[meta-viewport]--> --}}
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no"><!--ls:end[meta-viewport]--><!--ls:begin[stylesheet]-->
{{-- <link type="text/css" href="{{ asset('css/context.css')}}" rel="stylesheet">
<link type="text/css" href="./asset/css/base.css')}}" rel="stylesheet"> --}}

<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="{{ asset('css/mediaelementplayer.min.css')}}" rel="stylesheet">
<link type="text/css" href="{{ asset('css/sitefactory.css')}}" rel="stylesheet">
<link type="text/css" href="{{ asset('css/fontawesome-all.min.css')}}" rel="stylesheet">
<link type="text/css" href="{{ asset('css/base.css')}}" rel="stylesheet">
<!--ls:end[stylesheet]-->

<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="{{ asset('css/fix.css')}}" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="{{ asset('css/templates.css')}}" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[stylesheet]-->
<link type="text/css" href="{{ asset('css/templates.css')}}" rel="stylesheet">
<!--ls:end[stylesheet]-->
<!--ls:begin[script]-->
{{-- <script async="" src="{{ asset('js/faciliti-tag.min.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/bnpp-boot.js')}}"></script>
<script src="{{ asset('js/cookies.class.js')}}"></script> --}}
<!--ls:end[script]-->
<!--ls:begin[script]-->
{{-- <script type="text/javascript" src="{{ asset('js/jquery-1.11.0.min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/jquery.bxslider.min.4.1.1.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/jquery.easing.1.3.js')}}"></script> --}}
<!--ls:end[script]-->
{{-- <!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/modernizr-min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/jquery-ui-1.10.2.custom.min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/handlebars-v1.3.0.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/jquery.nanoscroller.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/jquery.validate.min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/waypoints.min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/webtrends.next.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/chart-min.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/main.min.js')}}"></script> --}}
<!--ls:end[script]-->
{{-- <!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/abtestingLoader.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/require-2.1.11-bnpp3.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/checkstatus.js')}}"></script>
<!--ls:end[script]-->

<!--ls:begin[script]-->

<script type="text/javascript" src="{{ asset('js/mediator-target-config.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/pagebus.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]--><script type="text/javascript" src="{{ asset('js/fix.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/chat_launcher.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/wcm-config.js')}}">
</script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/satelliteLoader.js')}}">
</script> --}}
<!--ls:end[script]-->
{{-- <!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/view.js')}}"></script>

<!--ls:end[script]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/fix_it.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[favicon]--> --}}
<link type="image/x-icon" src="{{ asset('images/favicon.ico')}}" rel="shortcut icon">
<!--ls:end[favicon]-->
<!--ls:begin[stylesheet]-->

<!--ls:end[stylesheet]-->
<!--ls:begin[script]-->
<script type="text/javascript" src="{{ asset('js/app.js')}}"></script>
<!--ls:end[script]-->
<!--ls:begin[script]-->
{{-- <script type="text/javascript" src="{{ asset('js/homepage-refresh.js')}}"></script> --}}
<!--ls:end[script]-->
<!--ls:begin[head-injection]-->
{{-- <meta name="siteid" content="part">
<meta name="google-site-verification" content="_mnVXosJLzxsXEcNjlJTCLS5s4HiX46wvUSGk4IXrik">
<meta name="FIELDDACLEVEL" content="-1">
<meta name="FIELDUSERTYPE" content="0">
<meta name="FIELDLANGUAGE" content="fr">
<meta name="FIELDCHANNEL" content="web">
<meta name="FIELDTERRITORY" content="world">
<meta name="FIELDAUDIENCE" content="pub">
<script type="text/javascript">
var sfAxes1 = "fr";
var sfAxes2 = "web";
var sfAxes3 = "world";
var sfAxes4 = "pub";
var sfSiteId = "part";
var sfCookieErrorPage = "cookieErrorPage.page";
var sfCustomerDacLevel = "0";</script>
<script type="text/javascript" src="{{ asset('js/sitefactory.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/mediator-target-config.js')}}"></script>
<script type="text/javascript" src="{{ asset('js/mediator.js')}}"></script>
<script type="text/javascript">
var sfPID = "indexf08";
var sfHP = "";
var sfSID = "WDL2smPmot315MIysGdcjhf_1410874521485";
var sfNodeId = "indexf08";
var sfVID = "";
var sfSg = "Primary";
</script> --}}
<!--ls:end[head-injection]-->
<!--ls:begin[script]-->
<!--ls:end[script]-->
{{-- <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery-bnpp" src="{{ asset('js/jquery-bnpp-1.3.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="rivets" src="{{ asset('js/rivets-0.6.5-bnpp1.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="waypoints" src="{{ asset('js/waypoints-bundle-2.0.5.js')}}"></script>
<meta name="WT.z_clienttype1" content="Particuliers">
<meta name="WT.site" content="mabanque.bnpparibas">
<script src="{{ asset('js/satelliteLib-cf28a06dbec8714383fde6faf0a3733075fff226.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="chart" src="{{ asset('js/chart-1.0.1-bnpp.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="donuts" src="{{ asset('js/doughnut-af913fb7.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="handlebars" src="{{ asset('js/handlebars-v1.3.0.js(1).js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="moment-2.6" src="{{ asset('js/moment-2.6.0-bnpp.js')}}"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jquery" src="{{ asset('js/jquery-1.11.0.js')}}"></script><meta name="WT.z_lang" content=""><meta name="WT.z_loggedin" content="0"><meta name="WT.z_appserver" content="prod_ap_a1_s2"><meta name="WT.z_livesite" content="prod_ls_a1_s1-CNET"><meta name="WT.cg_n" content="">

<meta name="WT.cg_s" content="">
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="jqueryui" src="{{ asset('js/jquery-ui-1.11.4.custom.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="handlebars.helpers" src="{{ asset('js/handlebar-helpers-9c725d09.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="underscore" src="{{ asset('js/underscore-1.4.4.js')}}"></script>
<script src="{{ asset('js/satellite-5a8bf1be64746d4ce8003310.js')}}"></script>
<script src="{{ asset('js/s-code-contents-0e4d8f8c34b8239ee4268ae46075686e426532a6.js')}}"></script> --}}
<link rel="stylesheet" href="{{ asset('css/style.css')}}" type="text/css">
{{-- <link rel="stylesheet" href="{{ asset('css/gestionCookies.css')}}" type="text/css"> --}}
{{-- <script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="google" src="{{ asset('js/js.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="contact.class" src="{{ asset('js/contact.class.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="gestionCookies" src="{{ asset('js/gestionCookies.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="contact" src="{{ asset('js/contact.js')}}"></script>
<script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="nousTrouver" src="{{ asset('js/nousTrouver.js')}}"></script>

<script type="text/javascript" charset="UTF-8" src="{{ asset('js/common.js')}}"></script>
<script type="text/javascript" charset="UTF-8" src="{{ asset('js/util.js')}}"></script>
<script type="text/javascript" charset="UTF-8" src="{{ asset('js/controls.js')}}"></script>
<script type="text/javascript" charset="UTF-8" src="{{ asset('js/places_impl.js')}}"></script> --}}
{{-- <script src="{{ asset('js/vendor/modernizr-2.8.3-respond-1.4.2.min.js')}}"></script>  --}}